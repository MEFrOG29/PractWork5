﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Runtime.Intrinsics.Arm;
using System.Security.Cryptography;

namespace Task2
{    
    public partial class AuthorizationWindow : Window
    {
        private string _password;
        
        public AuthorizationWindow()
        {
            InitializeComponent();
        }

        public string Hash(string text)
        {
            byte[] inputBytes = Encoding.UTF8.GetBytes(text);
            byte[] hashedBytes = SHA256.Create().ComputeHash(inputBytes);
            string hash = Convert.ToHexString(hashedBytes);
            return hash;
        }

        private void AuthorizationButton_Click(object sender, RoutedEventArgs e)
        {
            _password = ConfigurationManager.AppSettings["Password"];

           if (ConfigurationManager.AppSettings["Login"] == LoginTextBox.Text && 
               _password == Hash(PasswordBox.Password))
            {
                SettingsWindow settingsWindow = new ();
                settingsWindow.ShowDialog();
            }
           else
                MessageBox.Show("Неверные данные","Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}
