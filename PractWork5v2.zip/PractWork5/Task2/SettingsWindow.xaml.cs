﻿using System.Configuration;
using System.Security.Cryptography;
using System.Text;
using System.Windows;

namespace Task2
{
    /// <summary>
    /// Логика взаимодействия для SettingsWindow.xaml
    /// </summary>
    public partial class SettingsWindow : Window
    {

        public SettingsWindow()
        {
            InitializeComponent();
            PropertiesLoginTextBox.Text = ConfigurationManager.AppSettings["Login"];
            PropertiesEmailTextBox.Text = ConfigurationManager.AppSettings["Email"];
        }

        public string Hash(string text)
        {
            byte[] inputBytes = Encoding.UTF8.GetBytes(text);
            byte[] hashedBytes = SHA256.Create().ComputeHash(inputBytes);
            string hash = Convert.ToHexString(hashedBytes);
            return hash;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            var configuration = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            string hashedPassword = Hash(PropertiesPasswordTextBox.Text);
            configuration.AppSettings.Settings["Login"].Value = PropertiesLoginTextBox.Text;
            configuration.AppSettings.Settings["Password"].Value = hashedPassword;
            configuration.AppSettings.Settings["Email"].Value = PropertiesEmailTextBox.Text;
            configuration.Save();
            ConfigurationManager.RefreshSection("appSettings");
        }
    }
}
