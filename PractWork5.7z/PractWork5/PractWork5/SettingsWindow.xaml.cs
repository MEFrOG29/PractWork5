﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Task1
{
    /// <summary>
    /// Логика взаимодействия для SettingsWindow.xaml
    /// </summary>
    public partial class SettingsWindow : Window
    {
        public SettingsWindow()
        {
            InitializeComponent();
            PropertiesLoginTextBox.Text = Properties.Settings.Default.Login;
            PropertiesPasswordTextBox.Text = Properties.Settings.Default.Password;
            PropertiesEmailTextBox.Text = Properties.Settings.Default.Email;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.Login = PropertiesLoginTextBox.Text;
            Properties.Settings.Default.Password = PropertiesPasswordTextBox.Text;
            Properties.Settings.Default.Email = PropertiesEmailTextBox.Text;
            Properties.Settings.Default.Save();
        }
    }
}
