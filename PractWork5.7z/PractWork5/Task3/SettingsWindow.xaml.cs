﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Task3
{
    /// <summary>
    /// Логика взаимодействия для SettingsWindow.xaml
    /// </summary>
    public partial class SettingsWindow : Window
    {
        public SettingsWindow()
        {
            var userData = File.ReadAllLines("userData.txt");
            InitializeComponent();
            PropertiesLoginTextBox.Text = userData[0];
            PropertiesPasswordTextBox.Text = userData[1];
            PropertiesEmailTextBox.Text = userData[2];
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            File.Delete("userData.txt");
            StreamWriter streamWriter = new("userData.txt");
            streamWriter.WriteLine($"{PropertiesLoginTextBox.Text}");
            streamWriter.WriteLine($"{PropertiesPasswordTextBox.Text}");
            streamWriter.WriteLine($"{PropertiesEmailTextBox.Text}");
            streamWriter.Close();
        }
    }
}
