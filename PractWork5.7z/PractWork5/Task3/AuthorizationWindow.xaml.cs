﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Task3
{
    /// <summary>
    /// Логика взаимодействия для AuthorizationWindow.xaml
    /// </summary>
    public partial class AuthorizationWindow : Window
    {
        public AuthorizationWindow()
        {
            InitializeComponent();
        }

        private void AuthorizationButton_Click(object sender, RoutedEventArgs e)
        {
            var userData = File.ReadAllLines("userData.txt");
            if (userData[0] == LoginTextBox.Text &&
                userData[1] == PasswordTextBox.Text)
            {
                SettingsWindow settingsWindow = new ();
                settingsWindow.ShowDialog();
            }
            else
                MessageBox.Show("Неверные данные","Ошибка", MessageBoxButton.OK,MessageBoxImage.Error);
        }
    }
}
