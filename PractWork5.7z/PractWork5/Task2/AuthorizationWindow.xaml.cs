﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Runtime.Intrinsics.Arm;
using System.Security.Cryptography;

namespace Task2
{
    /// <summary>
    /// Логика взаимодействия для AuthorizationWindow.xaml
    /// </summary>
    public partial class AuthorizationWindow : Window
    {
        public string Hash(string text)
        {
            byte[] inputBytes = Encoding.UTF8.GetBytes(text);
            byte[] hashedBytes = SHA256.Create().ComputeHash(inputBytes);
            string hash = Convert.ToHexString(hashedBytes);
            return hash;
        }
        public AuthorizationWindow()
        {
            InitializeComponent();
        }

        
        private void AuthorizationButton_Click(object sender, RoutedEventArgs e)
        {
           //string hashedPassword = Hash(ConfigurationManager.AppSettings["Password"]);
           int hashCodeUserPassword = PasswordBox.Password.GetHashCode();
            int hashCodePassword = ConfigurationManager.AppSettings["Password"].GetHashCode();
           if (ConfigurationManager.AppSettings["Login"] == LoginTextBox.Text && 
                hashCodePassword == hashCodeUserPassword &&
               ConfigurationManager.AppSettings["Password"] == PasswordBox.Password)
            {
                SettingsWindow settingsWindow = new ();
                settingsWindow.ShowDialog();
            }
           else
                MessageBox.Show("Неверные данные","Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}
