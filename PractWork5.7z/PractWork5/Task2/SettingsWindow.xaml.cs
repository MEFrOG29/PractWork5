﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Security.Cryptography;

namespace Task2
{
    /// <summary>
    /// Логика взаимодействия для SettingsWindow.xaml
    /// </summary>
    public partial class SettingsWindow : Window
    {
        public string Hash(string text)
        {
            byte[] inputBytes = Encoding.UTF8.GetBytes(text);
            byte[] hashedBytes = SHA256.Create().ComputeHash(inputBytes);
            string hash = Convert.ToHexString(hashedBytes);
            return hash;
        }
        public SettingsWindow()
        {
            InitializeComponent();
            PropertiesLoginTextBox.Text = ConfigurationManager.AppSettings["Login"];
            PropertiesPasswordTextBox.Text = ConfigurationManager.AppSettings["Password"];
            PropertiesEmailTextBox.Text = ConfigurationManager.AppSettings["Email"];
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            var configuration = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            string hashedPassword = Hash(PropertiesPasswordTextBox.Text);
            configuration.AppSettings.Settings["Login"].Value = PropertiesLoginTextBox.Text;
            configuration.AppSettings.Settings["Password"].Value = hashedPassword;
            configuration.AppSettings.Settings["Email"].Value = PropertiesEmailTextBox.Text;
            configuration.Save();
            ConfigurationManager.RefreshSection("appSettings");
        }
    }
}
